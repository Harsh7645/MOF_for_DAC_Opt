from pathlib import Path
import difflib
R=Path.cwd();E=R/'evidence/qe75-baseline12-recovery-v2'
s=(R/'scripts/qe75_baseline12_worker_v1.py').read_text();t=s
old="""        be = max(time.time()-batch['allocation_start_unix'],
                 time.clock_gettime(time.CLOCK_BOOTTIME)-batch['start_boottime'],
                 time.monotonic()-batch['start_monotonic'])"""
new="""        clock_path = ROOT / c['batch_clock_file']
        if sha(clock_path) != c['batch_clock_sha256']:
            raise ValueError('Recovery clock anchor changed')
        clock = json.loads(clock_path.read_text())
        if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != clock['boot_id']:
            raise ValueError('Unexpected boot; never auto-resume')
        be = max(time.time()-batch['allocation_start_unix'],
                 clock['original_elapsed_at_recovery_s']+time.clock_gettime(time.CLOCK_BOOTTIME)-clock['recovery_boottime'],
                 clock['original_elapsed_at_recovery_s']+time.monotonic()-clock['recovery_monotonic'])"""
assert old in t;t=t.replace(old,new)
t=t.replace("        signal.signal(signal.SIGTERM, signal.SIG_IGN)\n        try:","        signal.signal(signal.SIGTERM, signal.SIG_IGN)\n        dump(ev/'cleanup-entered.json', {'time': time.time(), 'termination_reason': result['termination_reason'], 'cleanup_verified': False})\n        try:")
t=t.replace("    r = subprocess.run(args, capture_output=True, text=True, timeout=25)","""    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=25)
    except subprocess.TimeoutExpired as exc:
        if check:
            raise
        return {'args': args, 'returncode': 124, 'stdout': '', 'stderr': str(exc)}""")
(R/'scripts/qe75_baseline12_worker_v2.py').write_text(t);(E/'worker-controller.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='worker_v1',tofile='worker_v2')))
s=(R/'scripts/run_qe75_baseline12_v1.py').read_text();t=s.replace('qe75-baseline12-v1','qe75-baseline12-recovery-v2').replace('qe75_baseline12_worker_v1','qe75_baseline12_worker_v2').replace('run_qe75_baseline12_v1','run_qe75_baseline12_v2').replace('qe75-baseline12-', 'qe75-baseline12-v2-')
# Restore intended directories after unit-name replacement above.
t=t.replace('qe75-baseline12-v2-recovery-v2','qe75-baseline12-recovery-v2')
t=t.replace('import argparse,hashlib,json,math,os,shutil,subprocess,time,traceback','import argparse,hashlib,json,math,os,shutil,signal,subprocess,threading,time,traceback')
old=" return max(time.time()-b['allocation_start_unix'],time.clock_gettime(time.CLOCK_BOOTTIME)-b['start_boottime'],time.monotonic()-b['start_monotonic'])"
new=""" h=json.loads((E/'batch-clock-recovery.json').read_text())
 assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==h['boot_id'],'Boot changed; no automatic resume'
 return max(time.time()-b['allocation_start_unix'],h['original_elapsed_at_recovery_s']+time.clock_gettime(time.CLOCK_BOOTTIME)-h['recovery_boottime'],h['original_elapsed_at_recovery_s']+time.monotonic()-h['recovery_monotonic'])"""
assert old in t;t=t.replace(old,new)
t=t.replace("   note='Authorized one attempt", "   batch_clock_file=str(E/'batch-clock-recovery.json'),batch_clock_sha256=sha(E/'batch-clock-recovery.json'),\n   note='Authorized one recovery attempt")
t=t.replace("start=ba['allocation_start_unix'] if job['order']==1 else time.time()", "start=json.loads((E/'authorization.json').read_text())['recovery_preparation_start'] if job['order']==1 else time.time()")
t=t.replace("   result=launch.run_guard(c,ev/'config.json')", "   result=guard_with_progress(c,ev/'config.json',ledger,job)")
t=t.replace("current=None\n try:","current=None\n def stop_signal(signum,frame):\n  raise RuntimeError('batch_signal_'+str(signum)+'; possible OS/session shutdown')\n signal.signal(signal.SIGTERM,stop_signal)\n try:")
t=t.replace("ledger['traceback']=traceback.format_exc()", "ledger['traceback']=traceback.format_exc()\n  if current:current['status']='interrupted'\n  progress(ledger)  # durable state before any bus/service cleanup that could time out\n  signal.signal(signal.SIGTERM,signal.SIG_IGN)")
t=t.replace("for u in [c['unit'],c['unit'].replace('.service','-guardian.service')]:ctrl.command(['systemctl','--user','stop',u],False)", "for u in [c['unit'],c['unit'].replace('.service','-guardian.service')]:safe_cleanup(['systemctl','--user','stop',u],ev)")
t=t.replace("for kind in ('-grace.timer','-deadline.timer'):ctrl.command(['systemctl','--user','stop',c['unit'].replace('.service',kind)],False)","for kind in ('-grace.timer','-deadline.timer'):safe_cleanup(['systemctl','--user','stop',c['unit'].replace('.service',kind)],ev)")
t=t.replace('BASELINE12_V1_PROGRESS','BASELINE12_V2_PROGRESS').replace('batch v1','batch recovery v2').replace('One attempt per manifest ID.','One recovery attempt for interrupted job01; one original attempt for each other ID.').replace('ONE attempt/job,4h/jobinclprepcleanup','One newly authorized recovery for job01; otherwise ONE attempt/job,4h/attemptinclprepcleanup')
a=" lines+=['',f\"Blocker: {ledger.get('blocker','none')}\""
b=""" lines+=['', 'Updated UTC: '+ledger['updated_UTC'], 'Automatic update every 10 minutes while active, and on every start/finish/stop.', 'Original batch deadline: 2026-10-11 09:17:37 UTC (14:47:37 IST); Windows/offline time counts.', 'Previous job01 attempt interrupted by confirmed switch to Windows; preserved under v1. Recovery uses clean new directory because XML/density checkpoint is absent.', 'Do not reboot, log out, switch OS or close the lid during calculation. Sleep inhibition does not prevent shutdown.', '']
 for job in ledger['jobs']:
  if job['status']=='active':
   lines+=['## Live job '+str(job['order']), '', '```json', json.dumps(job.get('live',{}),indent=2), '```', '']
 lines+=['',f"Blocker: {ledger.get('blocker','none')}"""
assert a in t;t=t.replace(a,b)
insert='''
def safe_cleanup(args,ev):
 try:return ctrl.command(args,False)
 except Exception as ex:
  with (ev/'cleanup-errors.log').open('a') as f:f.write(repr(args)+': '+repr(ex)+'\\n')
  return {'returncode':1,'error':repr(ex)}

def live_update(ledger,job):
 w=ROOT/job['work_root'];p=w/'status.json';live={'sample_available':p.exists()}
 if p.exists():
  st=json.loads(p.read_text());live={k:st.get(k) for k in ['time','allocation_elapsed','iteration_started','iterations_with_error_report','latest_error_Ry','memory_current','memory_peak','swap_current','memory_events','system_available','free_disk','scratch_bytes','AC_online']}
  live['sample_age_seconds']=time.time()-st['time']
  live['available_RAM_GiB']=st['system_available']/2**30;live['peak_memory_GiB']=st['memory_peak']/2**30
  live['inhibitor_verified']=bool(st['inhibitor'])
 if (w/'execution-started.json').exists():
  marker=json.loads((w/'execution-started.json').read_text());job['attempts']=1;job['total_attempts_including_interruption']=job.get('previous_attempts',0)+1
  live['compute_elapsed_s']=time.time()-marker['time'];live['cumulative_compute_s']=live['compute_elapsed_s']+job.get('previous_compute_s',0)
 job['live']=live;progress(ledger)
 with (E/'progress-history.jsonl').open('a') as f:f.write(json.dumps({'time':time.time(),'id':job['manifest_id'],'live':live})+'\\n')

def guard_with_progress(c,config,ledger,job):
 result={}
 def guard_thread():
  try:result['value']=launch.run_guard(c,config)
  except BaseException as ex:result['error']=ex
 thread=threading.Thread(target=guard_thread,daemon=True);thread.start();last=0
 while thread.is_alive():
  if time.time()-last>=600:live_update(ledger,job);last=time.time()
  thread.join(2)
 live_update(ledger,job)
 if 'error' in result:raise result['error']
 return result['value']

'''
t=t.replace('\ndef run():',insert+'\ndef run():')
(R/'scripts/run_qe75_baseline12_v2.py').write_text(t);(E/'coordinator.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='batch_v1',tofile='recovery_v2')))
